import json,re,hashlib
from pathlib import Path
from shapely.geometry import shape,mapping,Point,MultiLineString
from shapely.ops import transform,unary_union
from pyproj import Transformer
out=Path(__file__).resolve().parents[1];raw=out/'data'/'sources';rd=Transformer.from_crs(4326,28992,always_xy=True).transform;ll=Transformer.from_crs(28992,4326,always_xy=True).transform
places=json.loads((out/'places.json').read_text());features={};checks=[]
provinces=json.loads((raw/'provinces.json').read_text())
for f in provinces['features']:
 name=f['properties']['naam']
 if name not in ['Utrecht','Zuid-Holland','Noord-Holland']:continue
 p=next(p for p in places if p['name']==name and p['type']=='provincie');g=shape(f['geometry']);simple=transform(ll,transform(rd,g).simplify(25,preserve_topology=True));assert simple.is_valid
 ratio=abs(transform(rd,g).area-transform(rd,simple).area)/transform(rd,g).area;assert ratio<.002
 features[p['id']]={'type':'Feature','geometry':mapping(simple),'properties':{'name':name,'category':'provincie','source':'Kadaster / PDOK Bestuurlijke Gebieden','license':'CC-BY-4.0','sourceId':f['id'],'sourceUrl':'https://api.pdok.nl/kadaster/brk-bestuurlijke-gebieden/ogc/v1/collections/provinciegebied/items/'+f['id'],'retrievedAt':'2026-11-03','reviewStatus':'source_imported_geometry_checked','assessmentReady':True,'transformation':'Topologiebehoudend vereenvoudigd in RD met tolerantie 25 meter; terug naar WGS84.'}}
 checks.append({'name':name,'valid':simple.is_valid,'relativeAreaChange':round(ratio,6)})
for name in ['Lek','Nieuwe Maas','Nieuwe Waterweg','Noordzeekanaal','Amsterdam-Rijnkanaal']:
 d=json.loads((raw/(name.replace(' ','_')+'.json')).read_text());assert d['features'] and not any(l['rel']=='next' for l in d['links']);assert all(f['properties']['vwg_naam']==name for f in d['features'])
 lines=[]
 for f in d['features']:
  g=transform(rd,shape(f['geometry'])).simplify(10,preserve_topology=True);lines.extend(list(g.geoms) if g.geom_type=='MultiLineString' else [g])
 g=transform(ll,MultiLineString(lines));p=next(p for p in places if p['name']==name)
 features[p['id']]={'type':'Feature','geometry':mapping(g),'properties':{'name':name,'category':'water','source':'Rijkswaterstaat / PDOK NWB Vaarwegen','license':'CC0-1.0','sourceIds':[f['id'] for f in d['features']],'sourceUrl':next(l['href'] for l in d['links'] if l['rel']=='self'),'retrievedAt':'2026-11-03','reviewStatus':'coverage_review_pending','assessmentReady':False,'transformation':'Vaarwegvakken samengevoegd als MultiLineString en vereenvoudigd in RD met tolerantie 10 meter. Dit zijn vaarroutes, geen oevers of volledig wateroppervlak.'}}
 checks.append({'name':name,'segments':len(d['features']),'lengthKm':round(sum(transform(rd,shape(f['geometry'])).length for f in d['features'])/1000,2),'assessmentReady':False})
p=next(p for p in places if p['name']=='Vleuten');v=json.loads((raw/'westnl-16.json').read_text());coords=list(map(float,re.findall(r'[-\d.]+',v['doc']['centroide_ll'])));assert features['westnl-03']
assert shape(features['westnl-03']['geometry']).covers(Point(coords))
features[p['id']]={'type':'Feature','geometry':{'type':'Point','coordinates':coords},'properties':{'name':'Vleuten','category':'stad','source':'BAG / PDOK Locatieserver','license':'CC0-1.0','sourceId':v['doc']['id'],'sourceUrl':v['url'],'retrievedAt':'2026-11-03','reviewStatus':'representative_woonplaats_centroid','assessmentReady':True,'transformation':'BAG-woonplaatsmiddelpunt; representatief kaartpunt, geen plaatsgrens.'}}
d={'version':'2026-11-03-geometry-poc-1','features':features};(out/'geodata.json').write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')));(out/'geodata.js').write_text('window.TopoGeoData='+json.dumps(d,ensure_ascii=False,separators=(',',':'))+';\n')
(out/'geometry-checks.json').write_text(json.dumps({'checks':checks,'vleutenInsideUtrecht':True,'note':'Technische datacontrole, geen volledige onderwijsinhoudelijke acceptatie.'},ensure_ascii=False,indent=2))
print('Prepared',len(features),'source features;',len((out/'geodata.js').read_bytes()),'bytes');print(json.dumps(checks,ensure_ascii=False))
